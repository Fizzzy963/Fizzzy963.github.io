4-5-13 @6:08pm

Skin #4
Kirby
Playlist font is tahoma. Font used in the skin is Kristen ITC.
A non-functioning equalizer.
A Paint Kirby skin made to match the wallpaper I made. Inspired by my younger brother who used to(and still kinda does) love playing Kirby. Plus Kirby is just the cutest! Poyo!
-------
Please do not post this skin anywhere else without my permission.
-------
Skinned by NingyoTsukai
omichan204@yahoo.com
http://ningyotsukai.deviantart.com/