XawMMS - A skin in the style of the Athena X widgets

By Christopher Allen <cpcallen@ruah.dyndns.org>
Based on NeXTAmp2 v1.0pre1 by Jesse Kaufman <glandix@linuxfreak.com>

Homepage: http://ruah.dyndns.org/~cpcallen/skins/
